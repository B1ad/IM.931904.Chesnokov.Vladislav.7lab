﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab7
{
    public partial class Form1 : Form
    {
        private bool _firstLaunch = false;
        private FireDepartment _fireDepartment;
        public Form1()
        {
            InitializeComponent();
        }

        private void NextDay_Click(object sender, EventArgs e)
        {
            if(!_firstLaunch)
            {
                var button = sender as Button;
                button.Text = "След. месяц";

                _fireDepartment = new FireDepartment(
                    Convert.ToInt32(StartPopulation.Value)
                    );
                _fireDepartment.WorkUpdate();
                _firstLaunch = true;
            }
            else
            {
                _fireDepartment.WorkUpdate();
            }
            NumberOfIncidents.Text = _fireDepartment.Appeals.ToString();
            NumberOfStuff.Text = _fireDepartment.Staff.ToString();
            FireLiquidated.Text = _fireDepartment.Liquidations.ToString();
            AmountPopulation.Text = _fireDepartment.Population.ToString();
            chart1.Series[0].Points.AddXY(_fireDepartment.Day, _fireDepartment.Liquidations);
            chart1.Series[1].Points.AddXY(_fireDepartment.Day, _fireDepartment.Appeals);
        }
    }    

    public class FireDepartment
    {
        private double _lifeQuality;
        private int _population;
        private int _day;

        private int _appeals;        
        private int _liquidations;

        private int _staff;
        private int _preventions;        

        private Random _random = new Random();

        public int Day => _day;
        public int Appeals => _appeals;
        public int Liquidations => _liquidations;
        public int Staff => _staff;
        public int Population => _population;
        
        public FireDepartment(int population)
        {            
            _population = population;
            _staff = Convert.ToInt32(500);
            _preventions = Convert.ToInt32(_staff * 0.2);
            _lifeQuality = _staff * 75.0 / _population;
            _lifeQuality = _lifeQuality >= 1 ? 1 : _lifeQuality;
        }

        private void City()
        {            
            var dif = 1 + 0.1 * (_random.NextDouble() - 0.5);
            _population = Convert.ToInt32(dif * _population);

            _staff = Convert.ToInt32(_population / 500);
            _preventions = Convert.ToInt32(_staff * 0.2);
            var politQuality = 2.5 * _preventions / _population;

            _lifeQuality += (0.05 * (_random.NextDouble() - 0.5)) + politQuality;
            _lifeQuality = _lifeQuality >= 1 ? 1 : _lifeQuality;

            _appeals = Convert.ToInt32(_population / _lifeQuality / 500);
            _day++;

        }

        public void WorkUpdate()
        {
            City();
            _liquidations = 0;
            var prevIncidents = _appeals;

            var currentIncidents = Convert.ToInt32(0.35f * _appeals);
            _appeals -= (currentIncidents - _preventions) >= 0 ? _preventions : currentIncidents;

            for (int i = 0; i < (prevIncidents - _appeals); i++)
            {
                _liquidations++;
            }
            _appeals = prevIncidents;
        }

    }

}
